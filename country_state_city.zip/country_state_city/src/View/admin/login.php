<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }
        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="container">
                <div class="form-container">
                    <h2 class="form-header text-center">Admin Login</h2>
                    <form method="POST">
                        <div class="form-group">
                            <label for="email" class="mb-2">Enter Email</label><br>
                            <input type="text" class="form-control <?php echo $emailEmpty ? 'is-invalid' : ''; ?>" name="email" placeholder="Enter Your Email" value="<?php echo htmlspecialchars($email ?? '', ENT_QUOTES); ?>">
                            <div class="invalid-feedback"><?php echo $emailEmpty; ?></div>

                            <label for="password" class="mb-2 mt-3">Enter Password</label><br>
                            <input type="password" class="form-control <?php echo $passwordEmpty || $passwordError ? 'is-invalid' : ''; ?>" name="password" placeholder="Enter Your Password">
                            <div class="invalid-feedback"><?php echo $passwordEmpty ? $passwordEmpty : $passwordError; ?></div>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary btn-block mb-4 mt-4">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>