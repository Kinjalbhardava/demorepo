<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            margin-left: -100px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 bg-light text-dark p-4 slidebar" id="sidebar">
                <h2 class="ps-4 pb-3">Admin</h2>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="/country_state_city/"><i
                                class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/country_state_city/country"><i class="fas fa-flag"></i> Country</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="/country_state_city/state"><i class="fas fa-map-marker-alt"></i>
                            State</a></li>  
                    <li class="nav-item"><a class="nav-link" href="/country_state_city/city"><i class="fas fa-building"></i> City</a>
                    </li>
                    <li class="nav-item">
                            <a class="nav-link" href="/country_state_city/logout"><i class=" fas fa-sign-out-alt"></i> Logout</a>
                        </li>
                </ul>
            </div>
        <div class="container">
            <div class="form-container">
                <h2 class="text-center"><?php echo $id ? 'Update State' : 'Add State'; ?></h2>
                <form method="POST" novalidate>
                <div class="form-group">
                        <label for="country_id" class="mb-2 mt-2">Select Country</label>
                        <select id="country_id" name="country_id"
                            class="form-control <?php echo !$country_valid ? 'is-invalid' : ''; ?>">
                            <option value="">Select Country</option>
                            <?php
                            while ($row = $result->fetch_assoc()) {
                                $selected = ($row['id'] == $country_id) ? 'selected' : '';
                                echo "<option value=\"{$row['id']}\" $selected>{$row['name']}</option>";
                            }
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select a country.</div>
                    </div>
                    <div class="form-group">
                        <label for="name" class="mb-2 mt-2">Enter State Name</label>
                        <input type="text" class="form-control <?php echo !$name_valid ? 'is-invalid' : ''; ?>"
                            name="name" value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>"
                            placeholder="Enter state name">

                        <div class="invalid-feedback">
                            <?php echo ($state_exists_available_error); ?>
                        </div>
                        <div class="invalid-feedback"> <?php echo ($state_pattern_error); ?>
                        </div>
                        <div class="invalid-feedback">
                            <?php echo ($state_exists_error); ?>
                        </div>
                        <div class="invalid-feedback">
                            <?php echo ($state_empty_error); ?>
                        </div>
                        <div class="invalid-feedback">
                            <?php echo ($state_pattern_match); ?>
                        </div>
                    </div>
                    <input type="submit" name="submit" class="btn btn-primary mb-3 mt-3" value="Submit">
                    <p>Don't want to add a state? <a href="/country_state_city/state">Go Back</a></p>
                </form>
            </div>
        </div>

    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>