<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-2 bg-light text-dark p-4 slidebar" id="sidebar">
                <h2 class="ps-4 pb-3">Admin</h2>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="/country_state_city/"><i
                                class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/country_state_city/country"><i class="fas fa-flag"></i> Country</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="/country_state_city/state"><i class="fas fa-map-marker-alt"></i>
                            State</a></li>  
                    <li class="nav-item"><a class="nav-link" href="/country_state_city/city"><i class="fas fa-building"></i> City</a>
                    </li>
                    <li class="nav-item">
                            <a class="nav-link" href="/country_state_city/logout"><i class=" fas fa-sign-out-alt"></i> Logout</a>
                        </li>
                </ul>
            </div>
            <div class="container">
                <div class="form-container">
                    <h2 class="form-header text-center"><?php echo ($id) ? 'Update City' : 'Add City'; ?></h2>
                    <form method="POST">
                        <div class="form-group">                                                                                                                                            
                            <label for="country_id" class="mb-2">Select Country</label>
                            <select id="country_id" name="country_id"
                                class="form-control mb-2 <?php echo !$country_valid ? 'is-invalid' : ''; ?>"
                                onchange="fetchStates();">
                                <option value="">Select Country</option>
                                <?php
                                    while ($row = $result->fetch_assoc()) {
                                        $selected = ($row['id'] == $country_id) ? 'selected' : '';
                                        echo "<option value=\"{$row['id']}\" $selected>{$row['name']}</option>";
                                    }
                                ?>
                            </select>
                            <div class="invalid-feedback">Please select a country.</div>
                        </div>
                                    
                        <div class="form-group">
                            <label for="state_id" class="mb-2">Select State</label>
                            <select id="state_id" name="state_id"
                                class="form-control mb-2 <?php echo !$state_valid ? 'is-invalid' : ''; ?>">
                                <option value="">Select State</option>
                                <?php
                                if (!empty($country_id)) {
                                    $con = new mysqli("localhost", "root", "Mysql@123", "state_city");
                                    $stmt = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
                                    $stmt->bind_param('i', $country_id);
                                    $stmt->execute();
                                    $resulti = $stmt->get_result();
                                    while ($row = $resulti->fetch_assoc()) {
                                        $selected = ($row['id'] == $state_id) ? 'selected' : '';
                                        echo "<option value=\"{$row['id']}\" $selected>{$row['s_name']}</option>";
                                    }
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Please select a state.</div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="mb-2">Enter City Name</label>
                            <input type="text"
                                class="form-control mb-2 <?php echo !$name_valid || !empty($city_exists_error) ? 'is-invalid' : ''; ?>"
                                name="name" value="<?php echo htmlspecialchars($name); ?>"
                                placeholder="Enter city name">
                            <div class="invalid-feedback">
                                <?php echo $city_empty_error ?: $city_pattern_match; ?>
                            </div>
                            <div class="invalid-feedback">
                                <?php echo $city_exists_error; ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mb-2 mt-2" id="submitBtn">Submit</button>
                        <p>Don't want to add a city? <a href="/country_state_city/city">Go Back</a></p>
                    </form>
                </div>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script>
                function fetchStates() {
                    const countryId = document.getElementById('country_id').value;
                    const stateSelect = document.getElementById('state_id');
                    stateSelect.innerHTML = '<option value="">Select State</option>';

                    if (countryId) {
                        fetch('/country_state_city/fetchstate?country_id=' + countryId)
                            .then(response => response.json())
                            .then(data => {
                                if (data.length > 0) {
                                    data.forEach(function (state) {
                                        const option = document.createElement('option');
                                        option.value = state.id;
                                        option.textContent = state.s_name;
                                        stateSelect.appendChild(option);
                                    }); 
                                } else {
                                    const option = document.createElement('option');
                                    option.value = '';
                                    option.textContent = 'No states available';
                                    stateSelect.appendChild(option);
                                }
                            })
                            .catch(error => console.error('Error fetching states:', error));
                    }
                }
            </script>
        </div>
    </div>
</body>
</html>