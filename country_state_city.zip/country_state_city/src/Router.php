<?php

namespace App;
// require_once('conn.php');

class Router
{
    // retrive method from url
    public function method()
    {
        return strtolower($_SERVER['REQUEST_METHOD']);
    }

    // retrive path from url
    public function path()
    {
        $url =  $_SERVER['REQUEST_URI'];
        if ($pos = strpos($url, '?')) {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
            $url = substr($url, 0, $pos);
        }
        return rtrim($url, '/');
    }

    // creating empty array for storing routing
    private static $router = [];

    // url filter method
    private static function clearUrl($url)
    {
        $url = rtrim($url, '/');
        return filter_var($url, FILTER_SANITIZE_URL);

    }
    // class filter method
    private static function clearClass($class)
    {
        return preg_replace('/[^a-zA-Z0-9_]/', '', $class);

    }
    // method filter method 
    private static function clearMethod($method)
    {
        return preg_replace('/[^a-zA-Z0-9_]/', '', $method);

    }

    // get method storing in array
    public static function get($url, $class, $method)
    {
        $url = self::clearUrl($url);
        $class = self::clearClass($class);
        $method = self::clearMethod($method);

        self::$router['get'][$url] = [
            'class' => $class,
            'method' => $method
        ];

    }
    // post method storing in array
    public static function post($url, $class, $method)
    {
        $url = self::clearUrl($url);
        $class = self::clearClass($class);
        $method = self::clearMethod($method);

        self::$router['post'][$url] = [
            'class' => $class,
            'method' => $method
        ];
    }
    // match method for match currunt routes with stores routes
    private function match($method, $url)
    {
        $url = rtrim($url,  '/');

        if (isset(self::$router[$method][$url])) {
            return self::$router[$method][$url];
        }
        
        return false;
        
    }
    // run the  router 
    public function run()
    {
        $runCall = $this->match($this->method(), $this->path());
        if (!$runCall) {
            echo "error 404, Page Not Found";
        }
        
        $class = "App\\Controller\\" . $runCall['class'];
        $method = $runCall['method'];
        $db = new \mysqli('localhost',  'root', 'Mysql@123', 'state_city');
        $controller = new $class($db);
        $params = $_GET;
        call_user_func_array([$controller, $method], [$params]);   
    }
}