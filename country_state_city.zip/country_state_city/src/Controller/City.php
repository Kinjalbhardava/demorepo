<?php

namespace App\Controller;
use App\Model\CityModel;

session_start();

class City
{

    protected $db;
    protected $model;
    public function __construct($db)
    {
        $this->db = $db;
        $this->model = new CityModel($db);
        if (!isset($_SESSION['admin_email'])) {
            header("Location: /country_state_city/login");
            exit();
        }
    }

    public function index()
    {
        $status = isset($_GET['status']) ? $_GET['status'] : '';

        $search = isset($_GET['search']) ? trim($_GET['search']) : '';
        $search = preg_replace("/[^a-zA-Z0-9\s]/", "", $search);

        $order_by = isset($_GET['order_by']) ? $_GET['order_by'] : 'id';
        $sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';
        $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        $page = max($page, 1);

        // ordering
        if (isset($_GET['order_by']) && in_array($_GET['order_by'], ['id', 's_name', 'country_name'])) {
            $order_by = $_GET['order_by'];
        }

        if (isset($_GET['sort_order']) && in_array($_GET['sort_order'], ['ASC', 'DESC'])) {
            $sort_order = $_GET['sort_order'];
        }

        // Toggle sorting order for the next click

        $next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
        $icon = $sort_order === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';

        $total = $this->model->getTotal($search);
        $total_pages = ceil($total / 5);

        $city = $this->model->getData($search, $page, $order_by, $sort_order);

        include('src/View/city/index.php');

    }

    // controller methods for insert and update
    public function fetchstate($country_id)
    {
        if (isset($_GET['country_id'])) {
            $country_id = $_GET['country_id'];
            $res = $this->model->getState($country_id);
            $states = [];
            while ($row = $res->fetch_assoc()) {
                $states[] = $row;
            }
            echo json_encode($states);
        }
    }

    public function InsertUpdate()
    {
        $name = '';
        $id = isset($_GET['id']) ? $_GET['id'] : '';
        $country_id = '';
        $state_id = '';
        $city_exists_error = '';
        $city_empty_error = '';
        $city_pattern_match = '';
        $name_valid = $country_valid = $state_valid = true;
    
        // fetching countries for the dropdown
        $result = $this->model->getCountries();
   
        if ($id) {
            $row = $this->model->getById($id);
            $state_id = $row['state_id'];
            $name = $row['c_name'];
            $country_id = $row['country_id'];
        }
    
        // $resu = $this->model->getState($country_id);
    
        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //   if(isset($_GET['country_id'])){
           
        //   }
              
            $name = trim($_POST['name']);
            $state_id = $_POST['state_id']; 
            $country_id = $_POST['country_id'];
    
            // Validation
            $name_valid = !empty($name) && preg_match('/^[a-zA-Z\s]+$/', $name);
            $country_valid = !empty($country_id);
            $state_valid = !empty($state_id);
    
            if (empty($name)) {
                $city_empty_error = "Please enter city name.";
            } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
                $city_pattern_match = "Please enter a valid city name.";
            } elseif ($name_valid && $country_valid && $state_valid) {
                // Check if the city already exists
                if ($this->model->exists($name, $state_id, $id)) {
                    $city_exists_error = "The city '{$name}' already exists in this state. Please choose a different name.";
                } else {
                    if ($id) {
                        $this->model->update($id, $name, $state_id);
                        header('Location: /country_state_city/city?status=update');
                        exit();
                    } else {
                        $this->model->add($name, $state_id);
                        header('Location: /country_state_city/city?status=success');
                        exit();
                    }
                }
            }
        }
        include('src/View/city/CityAdd.php');
    }
    
    // controller method for the delete
    public function DeleteData($id)
    {

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            if ($this->model->Delete($id))

                header('Location: /country_state_city/city?status=delete');

        } else {
            header('Location: /city');

        }
    }
}