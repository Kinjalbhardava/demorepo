<?php

namespace App\Controller;
use App\Model\DashboardModel;
session_start();

class Dashboard
{

    protected $db;
    protected $model;
    public function __construct($db)
    {
        $this->db = $db;
        $this->model = new DashboardModel($db);

        if(!isset($_SESSION['admin_email'])){
            header('Location: /country_state_city/login');
        }
    }

// count the no. of records of table
    public function index()
    {
       $countryCount = $this->model->getCountryData();
        $stateCount = $this->model->getStateData();
        $cityCount = $this->model->getCityData();
        include('src/View/index.php');

    }
    
}