<?php

namespace App\Controller;
session_start();
use App\Model\CountryModel;


class Country
{
    protected $db;
    protected $model;
    public function __construct($db)
    {
        $this->db = $db;
        $this->model = new CountryModel($db);
        if (!isset($_SESSION['admin_email'])) {
            header('Location: /country_state_city/login');
            exit();
        }

    }
    public function index()
    {

        $status = isset($_GET['status']) ? $_GET['status'] : '';

        $search = isset($_GET['search']) ? trim($_GET['search']) : '';
        $search = preg_replace("/[^a-zA-Z0-9\s]/", "", $search);

        $order_by = isset($_GET['order_by']) ? $_GET['order_by'] : 'id';
        $sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';
        $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        $page = max($page, 1);

        // ordering
        if (isset($_GET['order_by']) && in_array($_GET['order_by'], ['id', 'name'])) {
            $order_by = $_GET['order_by'];
        }

        if (isset($_GET['sort_order']) && in_array($_GET['sort_order'], ['ASC', 'DESC'])) {
            $sort_order = $_GET['sort_order'];
        }

        // Toggle sorting order for the next click

        $next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
        $icon = $sort_order === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';

        $total = $this->model->getTotal($search);
        $total_pages = ceil($total / 5);


        $country = $this->model->getData($search, $page, $order_by, $sort_order);


        include('src/View/country/index.php');

    }
    public function InsertUpdate($data, $id = null)
    {
        // Initialize error variables and empty array
        $name = '';
        $id = isset($_GET['id']);
        $nameError = '';
        $existsError = '';
        $errors = [];

        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $row = $this->model->getById($id);
            $name = $row['name'];

        }
        if (isset($_POST['submit'])) {

            $name = trim($_POST['name']);
            // Validation
            if (empty($name)) {
                $nameError = "Please Enter Country Name.";
                $errors[] = $nameError;
            } elseif (!preg_match('/^[a-zA-Z\s\-]+$/', $name)) {
                $nameError = "Please Enter a Valid Country Name.";
                $errors[] = $nameError;
            } else {

                if ($this->model->exists($name, $id)) {
                    $existsError = "This Country Already Exists. Please Insert a New Record.";
                } else {
                    if ($id) {
                        if ($this->model->update($id, $name)) {
                            header('Location: /country_state_city/country?status=update');
                            exit();
                        }
                    } else {
                        if ($this->model->add($name)) {
                            header('Location: /country_state_city/country?status=success');
                            exit();
                        }

                    }
                }

            }

        }
        include('src/View/country/CountryAdd.php');
        return $errors;
    }



    // controller method for the delete
    public function DeleteData($id)
    {

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            if ($this->model->Delete($id))
                header('Location: /country?status=delete');

        } else {
            header('Location: /country');

        }

    }

}
