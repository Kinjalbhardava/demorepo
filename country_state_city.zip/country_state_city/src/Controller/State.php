<?php

namespace App\Controller;
use App\Model\StateModel;

session_start();
class State
{
    protected $db;
    protected $model;
    public function __construct($db)
    {
        $this->db = $db;
        $this->model = new stateModel($db);
        if (!isset($_SESSION['admin_email'])) {
            header("Location: /country_state_city/login");
            exit();
        }
    }
    public function index()
    {
        $status = isset($_GET['status']) ? $_GET['status'] : '';

        $search = isset($_GET['search']) ? trim($_GET['search']) : '';
        $search = preg_replace("/[^a-zA-Z0-9\s]/", "", $search);

        $order_by = isset($_GET['order_by']) ? $_GET['order_by'] : 'id';
        $sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';
        $page = isset($_GET['page']) ? $_GET['page'] : 1;
        $page = max($page, 1);

        // ordering
        if (isset($_GET['order_by']) && in_array($_GET['order_by'], ['id', 's_name', 'country_name'])) {
            $order_by = $_GET['order_by'];
        }

        if (isset($_GET['sort_order']) && in_array($_GET['sort_order'], ['ASC', 'DESC'])) {
            $sort_order = $_GET['sort_order'];
        }
        // Toggle sorting order for the next click
        $next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
        $icon = $sort_order === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';

        $total = $this->model->getTotal($search);
        $total_pages = ceil($total / 5);
        $state = $this->model->getData($search, $page, $order_by, $sort_order);

        include('src/View/state/index.php');

    }


    // controller methods for insert and update


    public function InsertUpdate()
    {
        // fetching data for view showing

        $result = $this->model->getCountries();
        // $res = $this->model->get

        // Initialize error variables and empty array
        $name = '';
        $id = isset($_GET['id']) ? (int) $_GET['id'] : '';
        $country_id = '';
        $state_exists_error = '';
        $state_pattern_match = '';
        $state_empty_error = '';
        $name_valid = $country_valid = true;

        // fetching data for updation
        if ($id) {
            $row = $this->model->getById($id);
            $name = $row['s_name'];
            $country_id = $row['country_id'];

        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $name = trim($_POST['name']);
            $country_id = (int) $_POST['country_id'];

            $name_valid = !empty($name) && preg_match('/^[a-zA-Z\s]+$/', $name);
            $country_valid = !empty($country_id);
            // Validation
            if (empty($name)) {
                $state_empty_error = "Please Enter State Name";
            } elseif (!preg_match('/^[a-zA-Z\s\-]+$/', $name)) {
                $state_pattern_match = "Please Enter Valid State Name";
            } elseif ($name_valid && $country_valid) {
                if ($this->model->exists($name, $country_id, $id)) {
                    $state_exists_error = "The state '{$name}' already exists in this country. Please choose a different name for this country.";
                    $name_valid = false;
                }
                if ($name_valid) {
                    if ($id) {
                        $this->model->update($id, $name, $country_id);
                        header('Location: /country_state_city/state?status=update');
                        exit();
                    } else {
                        $this->model->add($country_id, $name);
                        header('Location: /country_state_city/state?status=success');
                        exit();
                    }
                }
            }

        }
        include('src/View/state/StateAdd.php');
        return $errorMsgs;
    }


    // controller method for the delete
    public function DeleteData($id)
    {
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            if ($this->model->Delete($id))
                header('Location: /country_state_city/state?status=delete');

        } else {
            header('Location: /country_state_city/state');

        }
    }
}
