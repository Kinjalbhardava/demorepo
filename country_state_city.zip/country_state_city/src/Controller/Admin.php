<?php
namespace App\Controller;
use App\Model\AdminModel;

session_start();

class Admin
{
    protected $db;
    protected $model;

    public function __construct($db)
    {
        $this->db = $db;
        $this->model = new AdminModel($db);
    }

    // Admin login
    public function login()
    {
        $emailEmpty = '';
        $passwordEmpty = '';
        $passwordError = ''; 
   

        // If already logged in, redirect
        if (isset($_SESSION['admin_email'])) {
            header("Location: /country_state_city/");
            exit();
        }

        // Process form submission
        if (isset($_POST['submit'])) {
            $email = trim($_POST['email']);
            $password = trim($_POST['password']);

            // Validate email
            if (empty($email)) {
                $emailEmpty = "Please Enter Email";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailEmpty = "Please enter a valid email address.";
            }

            // Validate password
            if (empty($password)) {
                $passwordEmpty = "Please Enter Password";
            }

            // Proceed if no validation errors
            if (empty($emailEmpty) && empty($passwordEmpty)) {
                $result = $this->model->Login($email);

                if ($res = $result->fetch_assoc()) {
                    // Verify password 
                    if ($password == $res['password']) {
                        $_SESSION['admin_email'] = $email; 
                        header("Location: /country_state_city/?status=login");
                        exit();
                    } else {
                        $passwordError = "Invalid credentials";
                    }
                } else {
                    $passwordError = "Invalid credentials";
                }
            }
        }

        include('src/View/admin/login.php');
    }

    // Logout method
    public function logout()
    {
        session_destroy();
        header('Location: /country_state_city/login');
        exit();
    }
}
