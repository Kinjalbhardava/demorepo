<?php
namespace App\Model;

class CountryModel
{
    protected $db;
    public function __construct($db)
    {
        $this->db = $db;
    }
    public function getData($search, $page, $order_by, $sort_order, $items_per_page = 5)
    {
        $offset = ($page - 1) * $items_per_page;
        $query = "SELECT * FROM country";
        $searchParam = "%$search%";
        $query = $query . ($search ? " WHERE name LIKE ?" : "") . " ORDER BY $order_by $sort_order LIMIT ?, ?";
        $stmt = $this->db->prepare($query);
        if ($search) {
            $stmt->bind_param('sii', $searchParam, $offset, $items_per_page);
        } else {
            $stmt->bind_param('ii', $offset, $items_per_page);
        }
        $stmt->execute();
        return $stmt->get_result();
    }

    // total record found 

    public function getTotal($search)
    {
        $countQuery = "SELECT COUNT(*) FROM country" . ($search ? " WHERE name LIKE ?" : "");
        $countStmt = $this->db->prepare($countQuery);

        if ($search) {
            $searchParam = "%$search%";
            $countStmt->bind_param('s', $searchParam);
        }
        $countStmt->execute();

        return $countStmt->get_result()->fetch_row()[0];

    }

    // insert add update logic

    public function add($name)
    {
        $stmt = $this->db->prepare("INSERT INTO country(name) VALUES (?)");
        $stmt->bind_param('s', $name);
        return $stmt->execute();

    }

    // Method to update an existing country
    public function update($id, $name)
    {
        $stmt = $this->db->prepare("UPDATE country SET name = ? WHERE id = ?");
        $stmt->bind_param('si', $name, $id);

        return $stmt->execute();

    }
    public function exists($name, $id = null)
    {
        $query = "SELECT * FROM country WHERE name = ?";
        if ($id) {
            $query .= " AND id != ?";
        }

        $stmt = $this->db->prepare($query);
        if ($id) {
            $stmt->bind_param('si', $name, $id);
        } else {
            $stmt->bind_param('s', $name);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    public function getById($id)
    {
        $stmt = $this->db->prepare("SELECT name FROM country WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // delete method
    public function Delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM country WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }

}


