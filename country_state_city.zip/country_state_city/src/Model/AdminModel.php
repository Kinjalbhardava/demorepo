<?php
namespace App\Model;

class AdminModel
{
    protected $db;
    public function __construct($db)
    {
        $this->db = $db;
    }

    public function Login($email){
     
        $stmt = $this->db->prepare("SELECT * FROM admin_info WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        return  $stmt->get_result();

    }
}