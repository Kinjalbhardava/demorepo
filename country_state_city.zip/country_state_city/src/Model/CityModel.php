<?php
namespace App\Model;

class CityModel
{
    protected $db;
    public function __construct($db)
    {
        $this->db = $db;
    }
    public function getData($search, $page, $order_by, $sort_order, $items_per_page = 5)
    {
        $offset = ($page - 1) * $items_per_page;
        $query = "SELECT city.*, country.name AS country_name, states.s_name AS states_name 
          FROM city 
          JOIN states ON city.state_id = states.id 
          JOIN country ON states.country_id = country.id";
        $searchParam = "%$search%";
        $query = $query . ($search ? " WHERE c_name LIKE ?" : "") . " ORDER BY $order_by $sort_order LIMIT ?, ?";
        $stmt = $this->db->prepare($query);
        if ($search) {
            $stmt->bind_param('sii', $searchParam, $offset, $items_per_page);
        } else {
            $stmt->bind_param('ii', $offset, $items_per_page);
        }
        $stmt->execute();
        return $stmt->get_result();
    }

    // total record found 

    public function getTotal($search)
    {
        $countQuery = "SELECT COUNT(*) FROM city 
                JOIN states ON city.state_id = states.id 
                JOIN country ON states.country_id = country.id" .
            ($search ? " WHERE city.c_name LIKE ?" : "");
        $countStmt = $this->db->prepare($countQuery);

        if ($search) {
            $searchParam = "%$search%";
            $countStmt->bind_param('s', $searchParam);
        }
        $countStmt->execute();

        return $countStmt->get_result()->fetch_row()[0];

    }

    // country add update logic

    public function add($name, $state_id)
    {
        $stmt = $this->db->prepare("INSERT INTO city (c_name, state_id) VALUES (?, ?)");
        $stmt->bind_param('si', $name, $state_id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Method to update an existing states
    public function update($id, $name, $state_id)
    {
        $stmt = $this->db->prepare("UPDATE city SET c_name = ?, state_id = ? WHERE id = ?");
        $stmt->bind_param('ssi', $name, $state_id, $id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function exists($name, $state_id, $id=null)
    {
        $stmt =$this->db->prepare("SELECT * FROM city WHERE c_name = ? AND state_id = ? AND (id != ? OR ? = 0)");
        $stmt->bind_param('siii', $name, $state_id, $id, $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;

    }

    public function getById($id)
    {
        $stmt = $this->db->prepare("SELECT city.*, states.country_id FROM city 
                                        JOIN states ON city.state_id = states.id 
                                        WHERE city.id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // get data for view

    public function getCountries()
    {
        $stmt = $this->db->prepare("SELECT id, name FROM country");
        $stmt->execute();
        return $stmt->get_result();

    }
public function getState($country_id){
    $stmt = $this->db->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
    $stmt->bind_param('i', $country_id);
    $stmt->execute();
    return $stmt->get_result();
}

    // delete method

    public function Delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM city WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }

}


