<?php
namespace App\Model;

use ReflectionFunctionAbstract;

class StateModel
{
    protected $db;
    public function __construct($db)
    {
        $this->db = $db;
    }
    public function getData($search, $page, $order_by, $sort_order, $items_per_page = 5)
    {
        $offset = ($page - 1) * $items_per_page;
        $query = "SELECT states.*, country.name AS country_name FROM states JOIN country on states.country_id = country.id";
        // $query = "SELECT * FROM states JOIN country ON states.country_id = country.id";   
        $searchParam = "%$search%";
        $query = $query . ($search ? " WHERE s_name LIKE ?" : "") . " ORDER BY $order_by $sort_order LIMIT ?, ?";
        $stmt = $this->db->prepare($query);
        if ($search) {
            $stmt->bind_param('sii', $searchParam, $offset, $items_per_page);
        } else {
            $stmt->bind_param('ii', $offset, $items_per_page);
        }
        $stmt->execute();
        return $stmt->get_result();
    }

    // total record found 

    public function getTotal($search)
    {
        $countQuery = "SELECT COUNT(*) FROM states" . ($search ? " WHERE s_name LIKE ?" : "");
        $countStmt = $this->db->prepare($countQuery);

        if ($search) {
            $searchParam = "%$search%";
            $countStmt->bind_param('s', $searchParam);
        }
        $countStmt->execute();

        return $countStmt->get_result()->fetch_row()[0];

    }

    // insert add update logic

    public function add($country_id, $name)
    {
        $stmt = $this->db->prepare("INSERT INTO states (country_id, s_name) VALUES (?, ?)");
        $stmt->bind_param('is', $country_id, $name);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Method to update an existing states
    public function update($id, $name, $country_id)
    {
        $stmt = $this->db->prepare("UPDATE states SET s_name = ?, country_id = ? WHERE id = ?");
        $stmt->bind_param('ssi', $name, $country_id, $id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function exists($name, $country_id, $id = null)
    {
        $query = "SELECT * FROM states WHERE s_name = ? AND country_id = ?";

        if ($id) {
            $query .= " AND id != ?";
        }
        $stmt = $this->db->prepare($query);
        if ($id) {
            $stmt->bind_param('sii', $name, $country_id, $id);
        } else {
            $stmt->bind_param('si', $name, $country_id);

        }
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;

    }

    public function getById($id)
    {
        $stmt = $this->db->prepare("SELECT s_name, country_id FROM states WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // get data for view

    public function getCountries()
    {
        $stmt = $this->db->prepare("SELECT id, name FROM country");
        $stmt->execute();
        return $stmt->get_result();

    }
    // delete method

    public function Delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM states WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }

}


