<?php

namespace App\Model;
class DashboardModel{
    protected $db;
    public function __construct($db){
        $this->db = $db;
    }

    public function getCountryData(){
        $query = "SELECT COUNT(id) as country_count from country";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->get_result()->fetch_row() [0] ?? 0;
    }

    public function getStateData(){
        $query = " SELECT COUNT(id) as state_count from states";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->get_result()->fetch_row()[0] ?? 0;
    }

    public function getCityData(){
        $query = " SELECT COUNT(id) as city_count from city";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->get_result()->fetch_row()[0] ?? 0;
    }

}

