<?PHP

$db = new mysqli("localhost", "root", "Mysql@123", "state_city");
if($db->connect_error){
    die("connection error" . $db->connect_error);
}